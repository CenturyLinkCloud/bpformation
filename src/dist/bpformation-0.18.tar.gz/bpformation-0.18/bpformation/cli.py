"""CLI console script entry point."""

import bpformation


def main():

	bpformation.Args()
	bpformation.ExecCommand()



