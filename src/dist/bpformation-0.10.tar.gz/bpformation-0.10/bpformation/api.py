# -*- coding: utf-8 -*-
"""Private class that proxies API calls."""

import clc
import requests

import bpformation

#
# TODO vCur:
#

#
# TODO vNext:
#

try:
	requests.packages.urllib3.disable_warnings()
except:
	pass

class API():
	pass

